import { Phone, Mail } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface SiteData {
  site: {
    title: string;
    phone: string;
    email: string;
    copyright: string;
  };
}

const Footer = () => {
  const { data } = useQuery<SiteData>({
    queryKey: ["content"],
    queryFn: async () => {
      const response = await fetch("/content.json");
      return response.json();
    },
  });

  return (
    <footer className="bg-secondary text-secondary-foreground py-8 mt-auto">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 className="text-lg font-bold mb-3">Контактная информация</h3>
            <div className="flex flex-col gap-2">
              <a
                href={`tel:${data?.site.phone.replace(/\D/g, "")}`}
                className="flex items-center gap-2 hover:text-accent transition-colors"
              >
                <Phone size={18} />
                <span>{data?.site.phone}</span>
              </a>
              <a
                href={`mailto:${data?.site.email}`}
                className="flex items-center gap-2 hover:text-accent transition-colors"
              >
                <Mail size={18} />
                <span>{data?.site.email}</span>
              </a>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-3">О компании</h3>
            <p className="text-sm opacity-90">
              Производство металлоконструкций и модульных объектов любой сложности.
              Качество, надёжность, профессионализм.
            </p>
          </div>
        </div>
        <div className="border-t border-border pt-4 text-center text-sm opacity-75">
          {data?.site.copyright}
        </div>
      </div>
    </footer>
  );
};

export default Footer;