import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import logo from "@/assets/logo.png";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const scrollToContact = () => {
    const contactSection = document.getElementById("contact-form");
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth" });
    }
    setIsMenuOpen(false);
  };

  const navLinks = [
    { to: "/about", label: "О компании" },
    { to: "/projects", label: "Примеры работ" },
  ];

  return (
    <header className="bg-background border-b border-border sticky top-0 z-50 shadow-sm">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <img src={logo} alt="Модульные решения" className="h-12 w-auto" />
            <span className="text-xl font-bold text-primary hidden sm:inline">
              Модульные решения
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`text-foreground hover:text-primary transition-colors ${
                  location.pathname === link.to ? "text-primary font-medium" : ""
                }`}
              >
                {link.label}
              </Link>
            ))}
            <button
              onClick={scrollToContact}
              className="text-foreground hover:text-primary transition-colors"
            >
              Контакты
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 text-foreground hover:text-primary transition-colors"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 flex flex-col gap-3 border-t border-border pt-4">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setIsMenuOpen(false)}
                className={`text-foreground hover:text-primary transition-colors py-2 ${
                  location.pathname === link.to ? "text-primary font-medium" : ""
                }`}
              >
                {link.label}
              </Link>
            ))}
            <button
              onClick={scrollToContact}
              className="text-foreground hover:text-primary transition-colors py-2 text-left"
            >
              Контакты
            </button>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;