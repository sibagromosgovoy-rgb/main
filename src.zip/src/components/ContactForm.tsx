import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface ContactFormProps {
  source?: string;
}

const ContactForm = ({ source = "Главная страница" }: ContactFormProps) => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim() || !phone.trim() || !message.trim()) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, заполните все поля",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    // TODO: Integrate with EmailJS or similar service
    // For now, just simulate submission
    setTimeout(() => {
      console.log("Form submitted:", { source, name, phone, message });
      
      toast({
        title: "Спасибо за обращение!",
        description: "Мы свяжемся с вами в ближайшее время.",
      });

      setName("");
      setPhone("");
      setMessage("");
      setIsSubmitting(false);
    }, 1000);

    // NOTE: To actually send emails, you need to:
    // 1. Sign up at https://www.emailjs.com/
    // 2. Create an email service and template
    // 3. Install emailjs-com: npm install emailjs-com
    // 4. Use the following code:
    /*
    import emailjs from 'emailjs-com';
    
    emailjs.send(
      'YOUR_SERVICE_ID',
      'YOUR_TEMPLATE_ID',
      {
        from_page: source,
        from_name: name,
        phone: phone,
        message: message,
        to_email: 's.mosgovoy@yandex.ru'
      },
      'YOUR_PUBLIC_KEY'
    )
    .then(() => {
      toast({ title: "Спасибо за обращение!", description: "Мы свяжемся с вами в ближайшее время." });
      setName(""); setPhone(""); setMessage("");
    })
    .catch(() => {
      toast({ title: "Ошибка", description: "Не удалось отправить сообщение", variant: "destructive" });
    })
    .finally(() => setIsSubmitting(false));
    */
  };

  return (
    <div id="contact-form" className="bg-card rounded-lg shadow-lg p-6 md:p-8">
      <h2 className="text-2xl font-bold text-foreground mb-4">Связаться с нами</h2>
      <p className="text-muted-foreground mb-6">
        Заполните форму, и мы свяжемся с вами в ближайшее время
      </p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium mb-2">
            Имя *
          </label>
          <Input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ваше имя"
            required
          />
        </div>
        <div>
          <label htmlFor="phone" className="block text-sm font-medium mb-2">
            Телефон *
          </label>
          <Input
            id="phone"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="+7 (___) ___-__-__"
            required
          />
        </div>
        <div>
          <label htmlFor="message" className="block text-sm font-medium mb-2">
            Сообщение *
          </label>
          <Textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Опишите ваш запрос..."
            rows={4}
            required
          />
        </div>
        <Button type="submit" disabled={isSubmitting} className="w-full">
          {isSubmitting ? "Отправка..." : "Отправить"}
        </Button>
      </form>
    </div>
  );
};

export default ContactForm;