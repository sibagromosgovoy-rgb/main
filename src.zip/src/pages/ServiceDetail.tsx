import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ContactForm from "@/components/ContactForm";
import ProjectGallery from "@/components/ProjectGallery";
import NotFound from "./NotFound";

// Import all images
import barsMain from "@/assets/bars-main.jpg";
import bars1 from "@/assets/bars-1.jpg";
import bars2 from "@/assets/bars-2.jpg";
import bars3 from "@/assets/bars-3.jpg";
import bars4 from "@/assets/bars-4.jpg";
import bars5 from "@/assets/bars-5.jpg";
import bars6 from "@/assets/bars-6.jpg";
import bars7 from "@/assets/bars-7.jpg";
import bars8 from "@/assets/bars-8.jpg";
import bars9 from "@/assets/bars-9.jpg";
import bars10 from "@/assets/bars-10.jpg";

import cabinsMain from "@/assets/cabins-main.jpg";
import cabins1 from "@/assets/cabins-1.jpg";
import cabins2 from "@/assets/cabins-2.jpg";
import cabins3 from "@/assets/cabins-3.jpg";
import cabins4 from "@/assets/cabins-4.jpg";
import cabins5 from "@/assets/cabins-5.jpg";
import cabins6 from "@/assets/cabins-6.jpg";
import cabins7 from "@/assets/cabins-7.jpg";
import cabins8 from "@/assets/cabins-8.jpg";
import cabins9 from "@/assets/cabins-9.jpg";
import cabins10 from "@/assets/cabins-10.jpg";

import livingMain from "@/assets/living-main.jpg";
import living1 from "@/assets/living-1.jpg";
import living2 from "@/assets/living-2.jpg";
import living3 from "@/assets/living-3.jpg";
import living4 from "@/assets/living-4.jpg";
import living5 from "@/assets/living-5.jpg";
import living6 from "@/assets/living-6.jpg";
import living7 from "@/assets/living-7.jpg";
import living8 from "@/assets/living-8.jpg";
import living9 from "@/assets/living-9.jpg";
import living10 from "@/assets/living-10.jpg";

import checkpointMain from "@/assets/checkpoint-main.jpg";
import checkpoint1 from "@/assets/checkpoint-1.jpg";
import checkpoint2 from "@/assets/checkpoint-2.jpg";
import checkpoint3 from "@/assets/checkpoint-3.jpg";
import checkpoint4 from "@/assets/checkpoint-4.jpg";
import checkpoint5 from "@/assets/checkpoint-5.jpg";
import checkpoint6 from "@/assets/checkpoint-6.jpg";
import checkpoint7 from "@/assets/checkpoint-7.jpg";
import checkpoint8 from "@/assets/checkpoint-8.jpg";
import checkpoint9 from "@/assets/checkpoint-9.jpg";
import checkpoint10 from "@/assets/checkpoint-10.jpg";

import warehouseMain from "@/assets/warehouse-main.jpg";
import warehouse1 from "@/assets/warehouse-1.jpg";
import warehouse2 from "@/assets/warehouse-2.jpg";
import warehouse3 from "@/assets/warehouse-3.jpg";
import warehouse4 from "@/assets/warehouse-4.jpg";
import warehouse5 from "@/assets/warehouse-5.jpg";
import warehouse6 from "@/assets/warehouse-6.jpg";
import warehouse7 from "@/assets/warehouse-7.jpg";
import warehouse8 from "@/assets/warehouse-8.jpg";
import warehouse9 from "@/assets/warehouse-9.jpg";
import warehouse10 from "@/assets/warehouse-10.jpg";

import toiletsMain from "@/assets/toilets-main.jpg";
import toilets1 from "@/assets/toilets-1.jpg";
import toilets2 from "@/assets/toilets-2.jpg";
import toilets3 from "@/assets/toilets-3.jpg";
import toilets4 from "@/assets/toilets-4.jpg";
import toilets5 from "@/assets/toilets-5.jpg";
import toilets6 from "@/assets/toilets-6.jpg";
import toilets7 from "@/assets/toilets-7.jpg";
import toilets8 from "@/assets/toilets-8.jpg";
import toilets9 from "@/assets/toilets-9.jpg";
import toilets10 from "@/assets/toilets-10.jpg";

import complexMain from "@/assets/complex-main.jpg";
import complex1 from "@/assets/complex-1.jpg";
import complex2 from "@/assets/complex-2.jpg";
import complex3 from "@/assets/complex-3.jpg";
import complex4 from "@/assets/complex-4.jpg";
import complex5 from "@/assets/complex-5.jpg";
import complex6 from "@/assets/complex-6.jpg";
import complex7 from "@/assets/complex-7.jpg";
import complex8 from "@/assets/complex-8.jpg";
import complex9 from "@/assets/complex-9.jpg";
import complex10 from "@/assets/complex-10.jpg";

const galleryImages: Record<string, string[]> = {
  bars: [bars1, bars2, bars3, bars4, bars5, bars6, bars7, bars8, bars9, bars10],
  cabins: [cabins1, cabins2, cabins3, cabins4, cabins5, cabins6, cabins7, cabins8, cabins9, cabins10],
  living: [living1, living2, living3, living4, living5, living6, living7, living8, living9, living10],
  checkpoint: [checkpoint1, checkpoint2, checkpoint3, checkpoint4, checkpoint5, checkpoint6, checkpoint7, checkpoint8, checkpoint9, checkpoint10],
  warehouse: [warehouse1, warehouse2, warehouse3, warehouse4, warehouse5, warehouse6, warehouse7, warehouse8, warehouse9, warehouse10],
  toilets: [toilets1, toilets2, toilets3, toilets4, toilets5, toilets6, toilets7, toilets8, toilets9, toilets10],
  complex: [complex1, complex2, complex3, complex4, complex5, complex6, complex7, complex8, complex9, complex10],
};

const mainImages: Record<string, string> = {
  bars: barsMain,
  cabins: cabinsMain,
  living: livingMain,
  checkpoint: checkpointMain,
  warehouse: warehouseMain,
  toilets: toiletsMain,
  complex: complexMain,
};

interface Service {
  id: string;
  name: string;
  slug: string;
  fullDescription: string;
}

interface ContentData {
  services: Service[];
}

const ServiceDetail = () => {
  const { slug } = useParams<{ slug: string }>();

  const { data } = useQuery<ContentData>({
    queryKey: ["content"],
    queryFn: async () => {
      const response = await fetch("/content.json");
      return response.json();
    },
  });

  const service = data?.services.find((s) => s.slug === slug);

  if (!service) {
    return <NotFound />;
  }

  const images = galleryImages[service.id] || [];
  const mainImage = mainImages[service.id];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-foreground">
            {service.name}
          </h1>

          <div className="mb-12">
            <img
              src={mainImage}
              alt={service.name}
              className="w-full max-h-[500px] object-cover rounded-lg shadow-xl"
            />
          </div>

          <div className="prose prose-lg max-w-none mb-16">
            {service.fullDescription.split("\n\n").map((paragraph, index) => (
              <p key={index} className="mb-6 text-foreground leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>

          <div className="mb-16">
            <h2 className="text-3xl font-bold mb-6 text-foreground">Примеры работ</h2>
            <ProjectGallery images={images} />
          </div>

          <div className="max-w-2xl mx-auto">
            <ContactForm source={service.name} />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ServiceDetail;