import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HeroSlider from "@/components/HeroSlider";
import ContactForm from "@/components/ContactForm";
import barsMain from "@/assets/bars-main.jpg";
import cabinsMain from "@/assets/cabins-main.jpg";
import livingMain from "@/assets/living-main.jpg";
import checkpointMain from "@/assets/checkpoint-main.jpg";
import warehouseMain from "@/assets/warehouse-main.jpg";
import toiletsMain from "@/assets/toilets-main.jpg";
import complexMain from "@/assets/complex-main.jpg";

interface Service {
  id: string;
  name: string;
  slug: string;
  image: string;
  description: string;
}

interface ContentData {
  services: Service[];
}

const serviceImages: Record<string, string> = {
  "bars-main": barsMain,
  "cabins-main": cabinsMain,
  "living-main": livingMain,
  "checkpoint-main": checkpointMain,
  "warehouse-main": warehouseMain,
  "toilets-main": toiletsMain,
  "complex-main": complexMain,
};

const Home = () => {
  const { data } = useQuery<ContentData>({
    queryKey: ["content"],
    queryFn: async () => {
      const response = await fetch("/content.json");
      return response.json();
    },
  });

  const services = data?.services || [];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <HeroSlider />

        <section className="py-16 bg-industrial-light">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground">
              Наши направления деятельности
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service) => (
                <Link
                  key={service.id}
                  to={`/${service.slug}`}
                  className="group bg-card rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all hover-scale"
                >
                  <div className="aspect-[4/3] overflow-hidden">
                    <img
                      src={serviceImages[service.image]}
                      alt={service.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors">
                      {service.name}
                    </h3>
                    <p className="text-muted-foreground text-sm line-clamp-3">
                      {service.description}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto">
              <ContactForm />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Home;