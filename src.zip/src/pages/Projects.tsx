import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ContactForm from "@/components/ContactForm";
import barsMain from "@/assets/bars-main.jpg";
import cabinsMain from "@/assets/cabins-main.jpg";
import livingMain from "@/assets/living-main.jpg";
import checkpointMain from "@/assets/checkpoint-main.jpg";
import warehouseMain from "@/assets/warehouse-main.jpg";
import toiletsMain from "@/assets/toilets-main.jpg";
import complexMain from "@/assets/complex-main.jpg";

interface Service {
  id: string;
  name: string;
  slug: string;
  image: string;
}

interface ContentData {
  services: Service[];
}

const serviceImages: Record<string, string> = {
  "bars-main": barsMain,
  "cabins-main": cabinsMain,
  "living-main": livingMain,
  "checkpoint-main": checkpointMain,
  "warehouse-main": warehouseMain,
  "toilets-main": toiletsMain,
  "complex-main": complexMain,
};

const Projects = () => {
  const { data } = useQuery<ContentData>({
    queryKey: ["content"],
    queryFn: async () => {
      const response = await fetch("/content.json");
      return response.json();
    },
  });

  const services = data?.services || [];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-12 text-foreground text-center">
            Наши проекты
          </h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {services.map((service) => (
              <Link
                key={service.id}
                to={`/${service.slug}`}
                className="group bg-card rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all hover-scale"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={serviceImages[service.image]}
                    alt={service.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold text-foreground group-hover:text-primary transition-colors">
                    {service.name}
                  </h3>
                </div>
              </Link>
            ))}
          </div>

          <div className="max-w-2xl mx-auto">
            <ContactForm source="Примеры работ" />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Projects;