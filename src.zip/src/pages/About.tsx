import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

interface ContentData {
  about: {
    title: string;
    content: string;
  };
}

const About = () => {
  const { data } = useQuery<ContentData>({
    queryKey: ["content"],
    queryFn: async () => {
      const response = await fetch("/content.json");
      return response.json();
    },
  });

  const about = data?.about;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-foreground">
            {about?.title}
          </h1>
          <div className="prose prose-lg max-w-none">
            {about?.content.split("\n\n").map((paragraph, index) => (
              <p key={index} className="mb-6 text-foreground leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default About;